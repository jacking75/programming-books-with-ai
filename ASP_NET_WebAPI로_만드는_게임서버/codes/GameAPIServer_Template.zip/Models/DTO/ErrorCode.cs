﻿namespace GameAPIServer.Models.DTO;

public class ErrorCode
{
    public global::ErrorCode Result { get; set; } = global::ErrorCode.None;
}
