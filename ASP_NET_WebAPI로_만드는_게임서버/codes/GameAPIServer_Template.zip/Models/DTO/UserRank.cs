﻿namespace GameAPIServer.Models.DTO;

public class UserRankResponse : ErrorCode
{
    public long Rank { get; set; }
}
