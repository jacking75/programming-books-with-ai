﻿namespace GameAPIServer.Models.DTO;

public class LogoutResponse : ErrorCode
{
}
